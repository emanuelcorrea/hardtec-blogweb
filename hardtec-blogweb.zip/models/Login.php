<?php
require_once('Crud.php');

$db = new Crud();



?>