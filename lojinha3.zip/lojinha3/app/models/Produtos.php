<?php
namespace App\Models;

use Src\Core\Crud;

class Produtos extends Crud
{
    public function __construct()
    {
        parent::__construct('produtos');
    }

    public function getAllCategory()
    {
        parent::__construct('categorias');

        return $this->selectAssoc();
    }

    public function categoryBy($id)
    {
        $this->setQuery(
            "SELECT * FROM categorias WHERE subcategoria = $id"
        );

        return $this->executeQuery();
    }
}
