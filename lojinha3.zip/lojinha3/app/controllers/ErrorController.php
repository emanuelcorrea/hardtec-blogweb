<?php
namespace App\Controllers;

class ErrorController
{
    public function __construct()
    {
        echo "Oi, to no construct do Error!";
    }

}
