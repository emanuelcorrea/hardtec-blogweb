<?php
define('ENVIRONMENT', 'production');
// define('ENVIRONMENT', 'development');